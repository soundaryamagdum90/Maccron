//package com.maccron.generic.javautilities;
//
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.Random;
//
//public class JavaUtilities {
//
//    //Print message
//    public void print(String message) {
//        System.out.println(message);
//    }
//
//    //Generate random number
//    public int getRandomNumber() {
//        return new Random().nextInt(1000);
//    }
//
//    //Get current date on format dd-MM-yyyy
//    public String getCurrentDate() {
//        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
//        return sdf.format(new Date());
//    }
//
//    
//    }
//}
